﻿/*
	This file is replaced with platform-specific code from the /merges folder.
	More info at http://taco.visualstudio.com/en-us/docs/configure-app/#Content.
*/